<?php

/**
 * Adds the gw2-api-functions to each page.
 *
 * @author		Yavis <administrator@asguardian.de>
 * @copyright	2013 Sebastian Loehr
 * @license		GNU Lesser General Public License <http://www.gnu.org/licenses/lgpl.html>
 * @package		de.asguardian.gw2.api
 * @version 1.0.0
 * @since 01.11.2013
 */
class GW2ApiInterface {
     /**
     * Getting the JSON-Data from an url
     * @param String $url
     * @return JSON-Array
     */
    public function getData($url) {
        $return = file_get_contents($url);
        return json_decode($return, true);
    }
    /**
     * Function to get the current Match
     * @param Number $worldid
     * @return Array The Data of the current match.
     */
    public function getWvWMatch($worldid) {
        $matches = $this->getData("https://api.guildwars2.com/v1/wvw/matches.json");
        $matches = $matches["wvw_matches"];
        for($i = 0; $i < count($matches); $i=$i+1) {
            if($matches[$i]["red_world_id"] == $worldid) {
                $match = $matches[$i];
            } else if ($matches[$i]["blue_world_id"] == $worldid) {
                $match = $matches[$i];
            } else if ($matches[$i]["green_world_id"] == $worldid) {
                $match = $matches[$i];
            }
        }
        return $match;
    }
    /**
     * Get complete list of worlds in an language.
     * @param String $language Lang-Code (like 'de' or 'en')
     * @return JSON-Array List of all Worlds.
     */
    public function getWorldsList($language) {
        $worldlist = $this->getData("https://api.guildwars2.com/v1/world_names.json?lang=" . $language);
        return $worldlist;
    }
    /**
     * Look up the names of some worlds.
     * @param String $language Langcode like 'en'
     * @param int[] $worldids Array with worldids as ints.
     * @return String[] Array with names of the worlds looked up.
     */
    public function getWorldsNames($language, $worldids) {
        $worlds = $this->getWorldsList($language);
        for($j = 0; $j<count($worldids);$j++){
            for($i = 0; $i < count($worlds); $i++) {
                if($worldids[$j] == $worlds[$i]["id"]) {
                    $worldnames[] = $worlds[$i]["name"];
                }
            }
        }
        return $worldnames;
    }
    /**
     * Lookup and objectid in an array of objects
     * @param Array $objects
     * @param int $objectid
     * @return Object
     */
    public function searchWvWObject($objects, $objectid) {
        for($i = 0; $i<count($objects); $i++){
            if((int)$objects[$i]["id"] == $objectid) {
                return $objects[$i];
            }
        }
    }
    /**
     * Get Objects in WvW.
     * @param type $language
     * @return type
     */
    public function getWvWObjects($language) {
        return $this->getData("https://api.guildwars2.com/v1/wvw/objective_names.json?lang=".$language);
    }
    /**
     * Calculating the Points each Border made on an Borderland.
     * @param Array $mapsobjects
     * @param Array $WvWObjects Objects to get the names of. (getWvWObjects("de"))
     * @return int
     */
    public function calculateWvWMapPoints($mapsobjects, $WvWObjects) {
        $mappoint["Red"] = 0;
        $mappoint["Blue"] = 0;
        $mappoint["Green"] = 0;
        $mappoint["Neutral"] = 0;
        for($i=0;$i < count($mapsobjects);$i++) {
            $objname = $this->searchWvWObject($WvWObjects, $mapsobjects[$i]["id"]);
            $objname = $objname["name"];
            switch ($objname) {
                case "Schloss":
                    $addpoints = 35;
                    break;
                case "Feste":
                    $addpoints = 25;
                    break;
                case "Turm":
                    $addpoints = 10;
                    break;
                case "Rote Mine":
                    $addpoints = 5;
                    break;
                case "Grüne Mine":
                    $addpoints = 5;
                    break;
                case "Blaue Mine":
                    $addpoints = 5;
                    break;
                case "Rotes Sägewerk":
                    $addpoints = 5;
                    break;
                case "Grünes Sägewerk":
                    $addpoints = 5;
                    break;
                case "Blaues Sägewerk":
                    $addpoints = 5;
                    break;
                case "Sägemühle":
                    $addpoints = 5;
                    break;
                case "Fischerdorf":
                    $addpoints = 5;
                    break;
                case "Steinbruch":
                    $addpoints = 5;
                    break;
                case "Kreuzung":
                    $addpoints = 5;
                    break;
                case "Obstgarten":
                    $addpoints = 5;
                    break;
                case "Werkstatt":
                    $addpoints = 5;
                    break;
                default:
                    $addpoints = 0;
                    break;
            }
            $mappoint[$mapsobjects[$i]["owner"]] += $addpoints;
        }
        return $mappoint;
    }
    /**
     * Get the points of an WvW-Match, using the matchid.
     * @param int $matchid
     * @return Array All scores and tiks.
     */
    public function getWvWMatchPoints($matchid) {
        $matchinfos = $this->getData("https://api.guildwars2.com/v1/wvw/match_details.json?match_id=" . $matchid);
        $tiks["scores"]["Red"] = $matchinfos["scores"][0];
        $tiks["scores"]["Blue"] = $matchinfos["scores"][1];
        $tiks["scores"]["Green"] = $matchinfos["scores"][2];
        $WvWObjects = $this->getWvWObjects("de");
        for($i=0;$i<4;$i++) {
            $tiks[$matchinfos["maps"][$i]["type"]] = $this->calculateWvWMapPoints($matchinfos["maps"][$i]["objectives"], $WvWObjects);
        }
        $tiks["All"]["Red"] = $tiks["RedHome"]["Red"] + $tiks["GreenHome"]["Red"] + $tiks["BlueHome"]["Red"] + $tiks["Center"]["Red"];
        $tiks["All"]["Blue"] = $tiks["RedHome"]["Blue"] + $tiks["GreenHome"]["Blue"] + $tiks["BlueHome"]["Blue"] + $tiks["Center"]["Blue"];
        $tiks["All"]["Green"] = $tiks["RedHome"]["Green"] + $tiks["GreenHome"]["Green"] + $tiks["BlueHome"]["Green"] + $tiks["Center"]["Green"];
        return $tiks;
    }
}
