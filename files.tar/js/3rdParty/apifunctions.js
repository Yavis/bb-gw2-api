/**
 * Adds the gw2-api-functions to each page.
 *
 * @author		Yavis <administrator@asguardian.de>
 * @copyright	2013 Sebastian Loehr
 * @license		GNU Lesser General Public License <http://www.gnu.org/licenses/lgpl.html>
 * @package		de.asguardian.gw2.api
 * @subpackage	system.event.listener
 * @version 1.0.0
 * @since 23.10.2013
 */
/**
 * Get JSON-Data
 * @param {type} url where to get the data
 * @returns {unresolved} The JSON-Data as array.
 */
function getData(url) {
    var output;
    output = $.ajax({
            url: url,
            async: false,
            dataType: 'json'
        }).responseText;
    output = jQuery.parseJSON(output);
    return output;
}

/**
 * Function to get the current Match
 * @param Number worldid
 * @return Array The Data of the current match.
 */
function getWvWMatch(worldid) {
    var matches = getData("https://api.guildwars2.com/v1/wvw/matches.json");
    matches = matches.wvw_matches;
    var match;
    for(var i = 0; i < matches.length; i++) {
        if(matches[i].red_world_id == worldid) {
             match = matches[i];
        } else if (matches[i].blue_world_id == worldid) {
             match = matches[i];
        } else if (matches[i].green_world_id == worldid) {
             match = matches[i];
        }
    }
    return match;
}
/**
 * Get complete list of worlds in an language.
 * @param String language Lang-Code (like 'de' or 'en')
 * @return JSON-Array List of all Worlds.
 */
function getWorldsList(language) {
    var worldlist = getData("https://api.guildwars2.com/v1/world_names.json?lang="+language);
    return worldlist;
}
/**
 * Look up the names of some worlds.
 * @param String language Langcode like 'en'
 * @param int[] worldids Array with worldids as ints.
 * @return String[] Array with names of the worlds looked up.
 */
function getWorldsNames(language, worldids) {
    var worlds = getWorldsList(language);
    var worldnames = [];
    for(var j = 0; j < worldids.length;j++){
        for(var i = 0; i < worlds.length; i++) {
            if(worldids[j] == worlds[i].id) {
                 worldnames[j] = worlds[i].name;
            }
        }
    }
    return worldnames;
}
/**
 * Lookup and objectid in an array of objects
 * @param Array objects
 * @param int objectid
 * @return Object
 */
function searchWvWObject(objects, objectid) {
    for(var i = 0; i < objects.length; i++){
        if(objects[i].id == objectid) {
            return objects[i];
        }
    }
}
/**
 * Get Objects in WvW.
 * @param type language
 * @return type
 */
function getWvWObjects(language) {
    return getData("https://api.guildwars2.com/v1/wvw/objective_names.json?lang="+language);
}
